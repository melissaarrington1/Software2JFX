package sample.resources;

public class Login {
}
